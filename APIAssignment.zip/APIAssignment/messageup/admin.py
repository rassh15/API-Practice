from django.contrib import admin
from messageup.models import Message
# Register your models here.
admin.site.register(Message)